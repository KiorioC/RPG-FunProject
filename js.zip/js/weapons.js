import { createWeapon } from "./weapon.js";

export const weapons = [
  createWeapon("Ast", -20),
  createWeapon("Küchen Messer", 3),
  createWeapon("Bürgerliches Schwert", 5),
  createWeapon("Paladin's Hammer", 20),
  createWeapon("Schwert der tausend Wahrheiten", 99)
];
