import { createArmor } from "./armor.js";


export const armors = [
  createArmor("Komischer Fetzen", 1),
  createArmor("Lederrüstung", 5),
  createArmor("Programmierer Brille", 3),
  createArmor("Feurige Tunika", 10),
  createArmor("Paladin Rüstung", 40)
];
