export function createPlayer(name, health, weapon, armor) {
  const criticalChance = Math.floor(Math.random() * 61);

  return {
    name,
    health: Math.min(Math.max(health, 0), 100),
    weapon,
    armor,
    criticalChance
  };
}
