import { weapons } from "./weapons.js";
import { armors } from "./armors.js";
import { createPlayer } from "./player.js";


/*
* Lebenspunkte: 1 - 100
* Waffenschaden: 1 - 20
* Rüstungspunkte: Prozentual! 0 - 50%
* Kritische Trefferchance: 0 - 60%
*
* Objekte erzeugen: Funktion
* Entitäten (zb. Waffen) speichern im Array
* * */

const timo =   createPlayer("Timo", 100, weapons.find(weapon => weapon.name === "Paladin's Hammer"), armors.find(armor => armor.name === "Programmierer Brille"));
const marco = createPlayer("Marco", 100, weapons.find(weapon => weapon.name === "Schwert der tausend Wahrheiten"), armors.find(armor => armor.name === "Feurige Tunika"))


// timo.attack(marco); -> Schaden durch Waffe + kritischer Treffer + Rüstung => Lebenspunkte
// marco.attack(timo);

// timo.isAlive() -> true
// marco.isAlive() -> true

